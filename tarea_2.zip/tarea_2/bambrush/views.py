from django.shortcuts import render

# Create your views here.

# Indice:

def index(request):
	return render(request, 'bambrush/index.html')

# Nuestros productos:

def productos(request):
	return render(request, 'bambrush/productos.html')

# Views con un formulario de contacto:

def contacto(request):
	return render(request, 'bambrush/contacto.html')

# Views con la descripción de la empresa:

def acerca(request):
	return render(request, 'bambrush/acerca.html')

def menu(request):
	return render(request, 'bambrush/menu.html')

def resultado(request):
	d_nombre = request.POST['Nombre']
	d_apellidos = request.POST['Apellido']
	d_email = request.POST['correo']
	d_cel = request.POST['cel']
	d_opinion = request.POST['opinión']
	contexto = {"Nombre": d_nombre, "Apellido": d_apellidos, "correo": d_email, "cel": d_cel, "opinión": d_opinion}
	return render(request,'bambrush/resultado.html',contexto)
