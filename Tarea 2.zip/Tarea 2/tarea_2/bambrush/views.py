from django.shortcuts import render

# Create your views here.

# Indice:

def index(request):
	return render(request, 'bambrush/index.html')

# Nuestros productos:

def productos(request):
	return render(request, 'bambrush/productos.html')

# Views con un formulario de contacto:

def contacto(request):
	return render(request, 'bambrush/contacto.html')

# Views con la descripción de la empresa:

def acerca(request):
	return render(request, 'bambrush/acerca.html')

def menu(request):
	return render(request, 'bambrush/menu.html')

