from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
	path('', views.index, name='index'),
	path('productos', views.productos, name='productos'),
	path('contacto', views.contacto, name='contacto'),
	path('acerca', views.acerca, name='acerca'),
	path('menu', views.menu, name='menu')
]