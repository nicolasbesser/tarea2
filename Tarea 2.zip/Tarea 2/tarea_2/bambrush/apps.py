from django.apps import AppConfig


class BambrushConfig(AppConfig):
    name = 'bambrush'
